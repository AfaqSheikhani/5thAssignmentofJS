//q1

var age =+prompt('enter your age','age here..');
alert('i am '+age+' years old')



//q3

var birthyear =+prompt('enter your birth year','put here..');
document.write('my birth year is '+birthyear+'<br/>')
document.write('data type of my declared variable is a number')



//q4


name=prompt('enter your name')
prod=prompt('enter product name')
quant=prompt('enter quantity')


document.write(name+' ordered '+  quant  +   prod +' on XYZ Clothing store')